Exercise 4/3

1. The algorithm that would be used to find this room would be

2.

3.

4.

5.
